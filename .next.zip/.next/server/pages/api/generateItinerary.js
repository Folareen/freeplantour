"use strict";
(() => {
var exports = {};
exports.id = 389;
exports.ids = [389];
exports.modules = {

/***/ 93:
/***/ ((module) => {

module.exports = require("@auth0/nextjs-auth0");

/***/ }),

/***/ 8013:
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ 3118:
/***/ ((module) => {

module.exports = require("openai");

/***/ }),

/***/ 6198:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8013);
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_0__);

if (!process.env.MONGODB_URI) {
    throw new Error('Invalid/Missing environment variable: "MONGODB_URI"');
}
const uri = process.env.MONGODB_URI;
let client;
let clientPromise;
if (false) {} else {
    // In production mode, it's best to not use a global variable.
    client = new mongodb__WEBPACK_IMPORTED_MODULE_0__.MongoClient(uri);
    clientPromise = client.connect();
}
// Export a module-scoped MongoClient promise. By doing this in a
// separate module, the client can be shared across functions.
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (clientPromise);


/***/ }),

/***/ 6462:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _auth0_nextjs_auth0__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(93);
/* harmony import */ var _auth0_nextjs_auth0__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_auth0_nextjs_auth0__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3118);
/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(openai__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_mongodb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6198);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_auth0_nextjs_auth0__WEBPACK_IMPORTED_MODULE_0__.withApiAuthRequired)(async function handler(req, res) {
    const { user  } = await (0,_auth0_nextjs_auth0__WEBPACK_IMPORTED_MODULE_0__.getSession)(req, res);
    const client = await _lib_mongodb__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z;
    const db = client.db("Freeplantour");
    const userProfile = await db.collection("users").findOne({
        auth0Id: user.sub
    });
    if (!userProfile?.availableTokens) {
        res.status(403);
        return;
    }
    const configuration = new openai__WEBPACK_IMPORTED_MODULE_1__.Configuration({
        apiKey: process.env.OPENAI_API_KEY
    });
    const openai = new openai__WEBPACK_IMPORTED_MODULE_1__.OpenAIApi(configuration);
    const baseCompletion = await openai.createCompletion({
        model: "text-davinci-003",
        prompt: `${req.body.prompt}`,
        temperature: 0.8,
        max_tokens: 3800
    });
    const response = baseCompletion.data.choices.pop();
    console.log("response: ", response);
    const { output  } = response;
    console.log("OpenAI replied...", output?.text);
    const result = await fetch(`https://es.wikivoyage.org/w/api.php?origin=*&format=json&formatversion=2&action=parse&page=${req.body.userInput}&prop=text`);
    const respon = await result.json();
    console.log("THE RESPONSE!!!", respon);
    const content = respon?.parse?.text ?? "";
    // Eliminar el texto largo con caracteres HTML
    const cleanedContent = content.replace(/Esta guía es [\s\S]*?ayuda a mejorarlo/g, "");
    const cleanedContent2 = cleanedContent.replace(/Este artículo [\s\S]*?otros artículos/g, "");
    const cleanedContent3 = cleanedContent2.replace(/Este artículo [\s\S]*?GNU Free Documentation License/g, "");
    // Eliminar también la palabra "editar" que puede quedar suelta después de la eliminación anterior
    const finalContent = cleanedContent3.replace(/\beditar\b/g, "");
    console.log("final contenttttt", finalContent);
    await db.collection("users").updateOne({
        auth0Id: user.sub
    }, {
        $inc: {
            availableTokens: -1
        }
    });
    const itinerary = await db.collection("itineraries").insertOne({
        apiOutput: response.text,
        info: finalContent,
        title: req.body.userInput,
        userId: userProfile._id,
        created: new Date()
    });
    console.log("itinerary: ", itinerary);
    res.status(200).json({
        itineraryId: itinerary.insertedId
    });
}));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6462));
module.exports = __webpack_exports__;

})();