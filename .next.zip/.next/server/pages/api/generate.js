"use strict";
(() => {
var exports = {};
exports.id = 565;
exports.ids = [565];
exports.modules = {

/***/ 3118:
/***/ ((module) => {

module.exports = require("openai");

/***/ }),

/***/ 9722:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3118);
/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(openai__WEBPACK_IMPORTED_MODULE_0__);

const generateAction = async (req, res)=>{
    // Run first prompt
    console.log(`API: ${req.body.prompt}`);
    const baseCompletion = await openai.createCompletion({
        model: "text-davinci-003",
        prompt: `${req.body.prompt}`,
        temperature: 0.8,
        max_tokens: 3800
    });
    res.status(200).json({
        output: basePromptOutput
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (generateAction);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9722));
module.exports = __webpack_exports__;

})();