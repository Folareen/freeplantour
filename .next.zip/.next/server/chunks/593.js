"use strict";
exports.id = 593;
exports.ids = [593];
exports.modules = {

/***/ 593:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ ItinerariesProvider),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const ItinerariesContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default().createContext({});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ItinerariesContext);
function itinerariesReducer(state, action) {
    switch(action.type){
        case "addItineraries":
            {
                const newItineraries = [
                    ...state
                ];
                action.itineraries.forEach((itinerary)=>{
                    const exists = newItineraries.find((p)=>p._id === itinerary._id);
                    if (!exists) {
                        newItineraries.push(itinerary);
                    }
                });
                return newItineraries;
            }
        case "deleteItinerary":
            {
                const newItineraries = [];
                state.forEach((itinerary)=>{
                    if (itinerary._id !== action.itineraryId) {
                        newItineraries.push(itinerary);
                    }
                });
                return newItineraries;
            }
        default:
            return state;
    }
}
const ItinerariesProvider = ({ children  })=>{
    const [itineraries, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useReducer)(itinerariesReducer, []);
    const [noMoreItineraries, setNoMoreItineraries] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const deleteItinerary = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((itineraryId)=>{
        dispatch({
            type: "deleteItinerary",
            itineraryId
        });
    }, []);
    const setItinerariesFromSSR = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((itinerariesFromSSR = [])=>{
        dispatch({
            type: "addItineraries",
            itineraries: itinerariesFromSSR
        });
    }, []);
    const getItineraries = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(async ({ lastItineraryDate , getNewerItineraries =false  })=>{
        const result = await fetch(`/api/getItineraries`, {
            method: "POST",
            headers: {
                "content-type": "application/json"
            },
            body: JSON.stringify({
                lastItineraryDate,
                getNewerItineraries
            })
        });
        const json = await result.json();
        const itinerariesResult = json.itineraries || [];
        if (itinerariesResult.length < 5) {
            setNoMoreItineraries(true);
        }
        dispatch({
            type: "addItineraries",
            itineraries: itinerariesResult
        });
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ItinerariesContext.Provider, {
        value: {
            itineraries,
            setItinerariesFromSSR,
            getItineraries,
            noMoreItineraries,
            deleteItinerary
        },
        children: children
    });
};


/***/ })

};
;