"use strict";
exports.id = 773;
exports.ids = [773];
exports.modules = {

/***/ 4163:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo2.121d35b2.png","height":162,"width":288,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAgElEQVR42mMAgb36TYwg+i1DpewbhmoZEPuINkgMDZxRa/Q7p9oYyDD1IBNC1LcXojJsksQRnSbdE5pNWgZefXIgoT7bTkaGGwoNYAUbTFt9D+k1p2w2b3WbY9NuBxI7r1PPyHBJtgas4LZElfoZuXKH8wqVrjclqnVAYhcUKhgBkP0lezz38XgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 8773:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "T": () => (/* reexport */ Logo)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./assets/logo2.png
var logo2 = __webpack_require__(4163);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/Logo/Logo.js



const Logo = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "text-3xl text-center py-4 font-heading justify-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
            src: logo2/* default */.Z,
            alt: "Free Plan Tour",
            style: {
                opacity: "0.8",
                marginLeft: "auto",
                marginRight: "auto"
            }
        })
    });
};

;// CONCATENATED MODULE: ./components/Logo/index.js



/***/ })

};
;