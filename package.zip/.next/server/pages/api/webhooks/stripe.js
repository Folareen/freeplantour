"use strict";
(() => {
var exports = {};
exports.id = 105;
exports.ids = [105];
exports.modules = {

/***/ 8915:
/***/ ((module) => {

module.exports = require("@webdeveducation/next-verify-stripe");

/***/ }),

/***/ 2799:
/***/ ((module) => {

module.exports = require("micro-cors");

/***/ }),

/***/ 8174:
/***/ ((module) => {

module.exports = require("stripe");

/***/ }),

/***/ 3745:
/***/ ((module) => {

module.exports = import("firebase/app");;

/***/ }),

/***/ 1492:
/***/ ((module) => {

module.exports = import("firebase/firestore");;

/***/ }),

/***/ 8450:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "db": () => (/* binding */ db)
/* harmony export */ });
/* unused harmony export app */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3745);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1492);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_firestore__WEBPACK_IMPORTED_MODULE_1__]);
([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_firestore__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// Import the functions you need from the SDKs you need


// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBbWuYU_TmV0eqbzzbpGdxmlLVeFQCQxBQ",
    authDomain: "freeplantour.firebaseapp.com",
    projectId: "freeplantour",
    storageBucket: "freeplantour.appspot.com",
    messagingSenderId: "303816064772",
    appId: "1:303816064772:web:4db000ef7dddbd13989a51",
    measurementId: "G-Z2NYDY6Z6V"
};
// Initialize Firebase
const app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__.initializeApp)(firebaseConfig);
const db = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.getFirestore)(app);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2678:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var micro_cors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2799);
/* harmony import */ var micro_cors__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(micro_cors__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var stripe__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8174);
/* harmony import */ var stripe__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(stripe__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _webdeveducation_next_verify_stripe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8915);
/* harmony import */ var _webdeveducation_next_verify_stripe__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_webdeveducation_next_verify_stripe__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1492);
/* harmony import */ var _firebase_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8450);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_firestore__WEBPACK_IMPORTED_MODULE_3__, _firebase_config__WEBPACK_IMPORTED_MODULE_4__]);
([firebase_firestore__WEBPACK_IMPORTED_MODULE_3__, _firebase_config__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const cors = micro_cors__WEBPACK_IMPORTED_MODULE_0___default()({
    allowMethods: [
        "POST",
        "HEAD"
    ]
});
const config = {
    api: {
        bodyParser: false
    }
};
const stripe = stripe__WEBPACK_IMPORTED_MODULE_1___default()(process.env.STRIPE_SECRET_KEY);
const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;
const handler = async (req, res)=>{
    console.log("got to stripe webhook handler");
    if (req.method === "POST") {
        let event;
        try {
            event = await _webdeveducation_next_verify_stripe__WEBPACK_IMPORTED_MODULE_2___default()({
                req,
                stripe,
                endpointSecret
            });
        } catch (e) {
            console.log("ERROR: ", e);
        }
        switch(event.type){
            case "payment_intent.succeeded":
                {
                    const paymentIntent = event.data.object;
                    const userId = `${paymentIntent.metadata.sub}-${paymentIntent.metadata.email}`;
                    // get user data from firestore
                    const docRef = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_3__.doc)(_firebase_config__WEBPACK_IMPORTED_MODULE_4__.db, "users", userId);
                    const userDocSnap = await (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_3__.getDoc)(docRef);
                    // add 10 tokens to user's available tokens
                    const userDocRef = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_3__.doc)(_firebase_config__WEBPACK_IMPORTED_MODULE_4__.db, "users", userId);
                    await (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_3__.setDoc)(userDocRef, {
                        availableTokens: userDocSnap?.data()?.availableTokens ? Number(userDocSnap.data()?.availableTokens) + 10 : 10
                    });
                }
            default:
                console.log("UNHANDLED EVENT: ", event.type);
        }
        res.status(200).json({
            received: true
        });
    }
    console.log("done with stripe webhook handler");
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cors(handler));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2678));
module.exports = __webpack_exports__;

})();